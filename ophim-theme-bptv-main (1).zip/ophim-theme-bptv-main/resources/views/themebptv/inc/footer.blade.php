<footer class="Footer">
    <div class="Container">
        {!! get_theme_option('footer') !!}
    </div>
</footer>
